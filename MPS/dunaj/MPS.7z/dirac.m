function [out] = dirac(in)

    if in == 0
        out = 1;
    else
        out = 0;
    end
end