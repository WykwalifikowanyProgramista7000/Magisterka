clc; close all;

opady = importdata('opady.prn');
dunaj = importdata('dunaj.prn');

dunaj = dunaj(:,2);
opady = opady(:,2);

plot(dunaj)
plot(opady)

%% 
clc; close all;

% ===== cale te ======
t_t = 1;
Pe = 0.1;
% ====================

lambda = log(2)/(12*12.3);

t = length(opady);
dt = 1;
C_input = opady;
C_output = zeros(3,length(opady));
% dunaj_2 = zeros(3,length(dunaj));

for t_prim = 1:dt:length(opady)
    for NN = 1:3
        switch(NN)
            %piston model
            case 1
            f=C_input(t_prim)*(dirac(uint8((t-t_prim)-t_t))==inf)*exp(-lambda*(t-t_prim));
            %exponential model
            case 2
            f=C_input(t_prim)*1/t_t*exp(-(t-t_prim)/t_t)*exp(-lambda*(t-t_prim));
            %dispersion model
            case 3
            f=C_input(t_prim)*1/sqrt(4*pi*Pe*(t-t_prim)/t_t)*1/(t-t_prim)*...
            exp(-(1-(t-t_prim)/t_t)^2/(4*Pe*(t-t_prim)/t_t))*exp(-lambda*(t-t_prim));
        end
        C_output(NN, t_prim) = C_output(NN, t_prim) + f;
    end
end

plot(C_output(2,:))